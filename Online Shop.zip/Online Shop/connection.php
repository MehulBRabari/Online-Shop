<?php
$conn = mysqli_connect('localhost','root','','shoping');
if($conn) {
//    echo "connection successful";
}
else {
    echo "no connection";
}
mysqli_select_db($conn,'shoping');

?>