<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflair.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	<link rel="stylesheet" href="css/page.css">
	<title>Furniture Product</title>
<script src="js/script.js" defer></script>
</head>

<body class="container">
<a href="shop.php">BACK</a>
	<h3 class="title">Home & Furniture Product</h3>
	<div class="products-container">
		<div class="product" data-name="p-1">
			<img src="imag/chair.webp" height="150px" width="90%" alt="">
			<h3>Chair</h3>
			<div class="price">1600.00 Rs</div>
		</div>
	
     <div class="product" data-name="p-2">
			<img src="imag/sofa.jpg" height="150px" width="90%" alt="">
			<h3>Sofa</h3>
			<div class="price">10,000.00</div>
		</div>
     
     <div class="product" data-name="p-3">
			<img src="imag/Dining table.jpg" height="150px" width="90%" alt="">
			<h3>Dining Table</h3>
			<div class="price">8000.00 Rs</div>
		</div>

		<div class="product" data-name="p-4">
			<img src="imag/leptop stand.jpg" height="150px" width="90%" alt="">
			<h3>Leptop Stand</h3>
			<div class="price">1200.00 Rs</div>
		</div>
	
     <div class="product" data-name="p-5">
			<img src="imag/box frame.jpg" height="150px" width="90%" alt="">
			<h3>Box Frame</h3>
			<div class="price">400.00 Rs</div>
		</div>
     
     <div class="product" data-name="p-6">
			<img src="imag/table.jfif" height="150px" width="90%" alt="">
			<h3>Table</h3>
			<div class="price">3700.00 Rs</div>
		</div>

			<div class="product" data-name="p-7">
			<img src="imag/drower.webp" height="150px" width="90%" alt="">
			<h3>Drower</h3>
			<div class="price">2700.00 Rs</div>
		</div>
	
     <div class="product" data-name="p-8">
			<img src="imag/doar.webp" height="150px" width="90%" alt="">
			<h3>Doar</h3>
			<div class="price">13000.00 Rs</div>
		</div>
     
     <div class="product" data-name="p-9">
			<img src="imag/window.jpg" height="150px" width="90%" alt="">
			<h3>Window</h3>
			<div class="price">4000.00 Rs</div>
		</div>

	<div class="product" data-name="p-10">
			<img src="imag/wood furniture.jpg" height="150px" width="90%" alt="">
			<h3>Wood Furniture</h3>
			<div class="price">30,000.00 Rs</div>
		</div>
	
     <div class="product" data-name="p-11">
			<img src="imag/plant stand.jpg" height="150px" width="90%" alt="">
			<h3>Plant Stand</h3>
			<div class="price">200.00 Rs</div>
		</div>
     
     <div class="product" data-name="p-12">
			<img src="imag/tample.jpg" height="150px" width="90%" alt="">
			<h3>Small Tample</h3>
			<div class="price">5000.00 Rs</div>
		</div>


	</div>

<div class="products-preview">

   <div class="preview" data-target="p-1">
      <i class="fas fa-times"></i>
      <img src="imag/chair.webp" alt="">
      <h3>Chair</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span></span>
      </div>
      <p>We make living better.</p>
      <div class="price">1600.00 Rs</div>
      <div class="buttons">
         <a href="buy.php" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-2">
      <i class="fas fa-times"></i>
      <img src="imag/sofa.jpg" alt="">
      <h3>Sofa</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span></span>
      </div>
      <p>Sit back, relax, and sink into our sofas.</p>
      <div class="price">10,000.00 Rs</div>
      <div class="buttons">
         <a href="#" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>>
      </div>
   </div>

   <div class="preview" data-target="p-3">
      <i class="fas fa-times"></i>
      <img src="imag/Dining table.jpg" alt="">
      <h3>Dining Table</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span></span>
      </div>
      <p>Furniture that will leave people breathless..</p>
      <div class="price">8000.00 Rs</div>
      <div class="buttons">
         <a href="#" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>



<div class="preview" data-target="p-4">
      <i class="fas fa-times"></i>
      <img src="imag/leptop stand.jpg" alt="">
      <h3>Leptop Stand</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span></span>
      </div>
      <p></p>
      <div class="price">1200.00 Rs</div>
      <div class="buttons">
         <a href="#" class="buy">buy now</a>
         <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-5">
      <i class="fas fa-times"></i>
      <img src="imag/box frame.jpg" alt="">
      <h3>Box Frame</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">400.00 Rs</div>
      <div class="buttons">
         <a href="#" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-6">
      <i class="fas fa-times"></i>
      <img src="imag/table.jpg" alt="">
      <h3>Table</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">3700.00 Rs</div>
      <div class="buttons">
         <a href="#" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>


<div class="preview" data-target="p-7">
      <i class="fas fa-times"></i>
      <img src="imag/drower.png" alt="">
      <h3>Drower</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">2700.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-8">
      <i class="fas fa-times"></i>
      <img src="imag/doar.webp" alt="">
      <h3>Doar</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p>.</p>
      <div class="price">13000.0 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-9">
      <i class="fas fa-times"></i>
      <img src="imag/window.jpg" alt="">
      <h3>Window</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">4000.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

<div class="preview" data-target="p-10">
      <i class="fas fa-times"></i>
      <img src="imag/wood furniture.jpg" alt="">
      <h3>Wood Furniture</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">30,000.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-11">
      <i class="fas fa-times"></i>
      <img src="imag/plant stand.jpg" alt="">
      <h3>Plant Stand</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">200.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-12">
      <i class="fas fa-times"></i>
      <img src="imag/temple.jpg" alt="">
      <h3>Small Temple</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p>.</p>
      <div class="price">5000.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>


</div>
</body>
</html>