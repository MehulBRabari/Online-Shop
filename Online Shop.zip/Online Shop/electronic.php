<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflair.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	<link rel="stylesheet" href="css/page.css">
	<title>Electronic Product</title>
<script src="js/script.js" defer></script>
</head>

<body class="container">
<a href="shop.php">BACK</a>
	<h3 class="title">Electronics Product</h3>
	<div class="products-container">
		<div class="product" data-name="p-1">
			<img src="imag/switch.jpg" height="130px" width="90%" alt="">
			<h3>Fan Switch</h3>
			<div class="price">90.00 Rs</div>
		</div>
	
     <div class="product" data-name="p-2">
			<img src="imag/printer.jpg" height="145px" width="90%" alt="">
			<h3>Printer</h3>
			<div class="price">4500.00 Rs</div>
		</div>
     
     <div class="product" data-name="p-3">
			<img src="imag/hair.jpg" height="150px" width="90%" alt="">
			<h3>Hair Stretner</h3>
			<div class="price">1500.00 Rs</div>
		</div>
	
		<div class="product" data-name="p-4">
			<img src="imag/light.jpg" height="150px" width="80%" alt="">
			<h3>Tube Light</h3>
			<div class="price">500.00 Rs</div>
		</div>
	
     <div class="product" data-name="p-5">
			<img src="imag/istri.jpg" height="150px" width="90%" alt="">
			<h3></h3>
			<div class="price">900.00 Rs</div>
		</div>
     
     <div class="product" data-name="p-6">
			<img src="imag/leptop.jpg" height="150px" width="90%" alt="">
			<h3>Lenovo Leptop</h3>
			<div class="price">40,000.00 Rs</div>
		</div>

			<div class="product" data-name="p-7">
			<img src="imag/fan.jpg" height="150px" width="90%" alt="">
			<h3>Whole Fan</h3>
			<div class="price">3500.00 Rs</div>
		</div>
	
     <div class="product" data-name="p-8">
			<img src="imag/cooler.jpg" height="150px" width="90%" alt="">
			<h3>Cooler</h3>
			<div class="price">20,000.00 Rs</div>
		</div>
     
     <div class="product" data-name="p-9">
			<img src="imag/oven.jpg" height="150px" width="90%" alt="">
			<h3>Electronic Oven</h3>
			<div class="price">6000.00 Rs</div>
		</div>

	<div class="product" data-name="p-10">
			<img src="imag/tvremot.jpg" height="150px" width="90%" alt="">
			<h3>Panasonic Tv Remot</h3>
			<div class="price">300.00 Rs</div>
		</div>
	
     <div class="product" data-name="p-11">
			<img src="imag/mobile.jpg" height="150px" width="90%" alt="">
			<h3>I-Phone 12 Pro</h3>
			<div class="price">80,000.00</div>
		</div>
     
     <div class="product" data-name="p-12">
			<img src="imag/freez.jpg" height="150px" width="90%" alt="">
			<h3>Cool Freez</h3>
			<div class="price">50,000.00 Rs</div>
		</div>
       </div>

<div class="products-preview">

   <div class="preview" data-target="p-1">
      <i class="fas fa-times"></i>
      <img src="imag/switch.jpg" alt="">
      <h3>Fan Switch</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span></span>
      </div>
      <p>lets you change the direction of the fan blades.</p>
      <div class="price">90.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-2">
      <i class="fas fa-times"></i>
      <img src="imag/printer.jpg" alt="">
      <h3>Printer</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span></span>
      </div>
      <p>Benjamin Franklin was originally a printer..</p>
      <div class="price">4500.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-3">
      <i class="fas fa-times"></i>
      <img src="imag/hair.jpg" alt="">
      <h3>Hair Straightner</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span></span>
      </div>
      <p>Hair straighteners are great for styling your hair without having to visit the salon.</p>
      <div class="price">1500.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>



<div class="preview" data-target="p-4">
      <i class="fas fa-times"></i>
      <img src="imag/light.jpg" alt="">
      <h3>Tube Light</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span></span>
      </div>
      <p>Fluorescent tube lights can be used for commercial purposes.</p>
      <div class="price">500.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-5">
      <i class="fas fa-times"></i>
      <img src="imag/istri.jpg" alt="">
      <h3>Electronic Istri</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span></span>
      </div>
      <p></p>
      <div class="price">900.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-6">
      <i class="fas fa-times"></i>
      <img src="imag/leptop.jpg alt=">
      <h3>Lenovo Leptop</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span></span>
      </div>
      <p></p>
      <div class="price">$40,000.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>


<div class="preview" data-target="p-7">
      <i class="fas fa-times"></i>
      <img src="imag/fan.png" alt="">
      <h3>Fan</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">3500.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="#" class="cart">add to cart</a>
      </div>
   </div>

   <div class="preview" data-target="p-8">
      <i class="fas fa-times"></i>
      <img src="imag/cooler.png" alt="">
      <h3>Cooler</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">20,000.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="#" class="cart">add to cart</a>
      </div>
   </div>

   <div class="preview" data-target="p-9">
      <i class="fas fa-times"></i>
      <img src="imag/oven.png" alt="">
      <h3>Electronic Oven</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">6000.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="#" class="cart">add to cart</a>
      </div>
   </div>

<div class="preview" data-target="p-10">
      <i class="fas fa-times"></i>
      <img src="imag/tvremot.jpg" alt="">
      <h3>Panasonic Tv Remot</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">300.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="#" class="cart">add to cart</a>
      </div>
   </div>

   <div class="preview" data-target="p-11">
      <i class="fas fa-times"></i>
      <img src="imag/mobile.jpg" alt="">
      <h3>I-Phone 12 Pro</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">80,000.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="#" class="cart">add to cart</a>
      </div>
   </div>

   <div class="preview" data-target="p-12">
      <i class="fas fa-times"></i>
      <img src="imag/freez.jpg" alt="">
      <h3>Cool Freez</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span></span>
      </div>
      <p></p>
      <div class="price">50,000.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>


</div>
</body>
</html>