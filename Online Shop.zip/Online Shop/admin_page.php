<?php

@include 'connection.php';
session_start();
if(!isset($_SESSION['admin_name'])){
	header('location:login_form.php');
}
?>
<html lang="en">
<head>
<meta charset="utf-8">
 <meta http-equiv="X-UA-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/log.css">
</head>
<body>
<div class="container">
<div class="content">
<h3>Hi <span> admin </span></h3>
<h1>Welcome<br><span><?php echo $_SESSION['admin_name']?></span></h1>
<p>This is an admin page</p>
<a href="crud.php" class="btn">Product Management</a>
<a href="index.php" class="btn">Back to Home</a>
<a href="logout.php" class="btn" >Log out</a>
</div>
</div>
</body>
		
</html>