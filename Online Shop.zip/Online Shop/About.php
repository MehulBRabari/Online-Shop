<html>
<head>
	<title> </title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/team.css">
  <link rel="stylesheet" type="text/css" href="css/contact.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <!-- linking font awesome for icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

 
 
 <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,300&display=swap" rel="stylesheet">

</head>
<body style="background-color:#D3DCE9";>
 <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Our Shop</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link active" aria-current="right" href="index.php">Home</a>
        </li>
		
		<li class="nav-item">
          <a class="nav-link" href="shop.php">Shop</a>
        </li>
		
		<li class="nav-item">
          <a class="nav-link" href="About.php">Team</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="contact.php">Contact</a>
        </li>
         
		  <li class="nav-item">
          <a class="nav-link active" href="register_form.php">Registration</a>
        </li>
          </a>
        </ul>
     </div>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"><t>_</t>
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
<div class="jumbotron">
  <h1>Our shop</h1>
  <p>Welcome ALl Costomer Thank you for Visit Our shop :)</p>
</div>

<section class="my-5">
  <div>
    <h2 class="text-center">Meet Team Member</h2>
  </div>
 
 <center>
        <hr>
        <!-- First member of the team -->
        <div class="row">
            <div class="column" id="gfg">
                <div class="card">
                    <i class="fa fa-user-circle" style="font-size:68px;"></i>
                    <div class="container">
                        <h2>Mehul Rabari</h2>
                        <p>CEO & Founder</p>
                        <p>
                            Feel your customer make
                            them happy
                        </p>
 
                        <button class="button">View</button>
                    </div>
                </div>
            </div>
                        <!-- Other members of the team -->

            <div class="column">
                <div class="card">
                    <i class="fa fa-user-circle" style="font-size:68px;"></i>
                    <div class="container">
                        <h2>Dev Patel</h2>
                        <p>Developer Head</p>
                        <p>
                            A website should be user-friendly
                            and attractive
                        </p>
                        <button class="button">View</button>
                    </div>
                </div>
            </div>
 
            <div class="column">
                <div class="card">
                    <i class="fa fa-user-circle" style="font-size:68px;"></i>
                    <div class="container">
                        <h2>Jay Prajapati</h2>
 
                        <p>Marketing head</p>
 
                        <p>
                            Good in Marketing
							</p>
 
                        <button class="button">View</button>
                    </div>
                </div>
            </div>     
         </div>     
    </center>
 
 
 <!--- <div class="row">
    <div class="col-lg-6" class="col-md-6 col-12">
      <img src="imag/05.jpg" class="img-fluid aboutimg"/>
    </div>
 
<div class="col-lg-6" class="col-md-6 col-12">
      <h2 class="desplay-4">I am Mehul Rabari</h2>
      <p class="py-4">First of all thank you for visit my website
        I am BCA second year student  and provid this
        website your servises. My father name is Bhikhabhai.
        My mother name is Takhiben.This website use for 
        deffrent courses and understand deffrent part of
       course so thank you purchase this course and understand topic.</p>
<h2>
       <a href="About.php" class="btn btn-success">Check more</a>
    </div>
  </div>---->
</section>
</body>
</html>