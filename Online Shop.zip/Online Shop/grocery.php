<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflair.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	<link rel="stylesheet" href="css/page.css">
	<title>Grocery Product</title>
<script src="js/script.js" defer></script>
</head>

<body class="container" style="background-color:#D3DCE9">
<a href="shop.php">BACK</a>
	<h3 class="title">Grocery Product</h3>
	<div class="products-container">
		<div class="product" data-name="p-1">
			<img src="imag/cofee.jpg" height="150px" width="90%" alt="">
			<h3>Cofee</h3>
			<div class="price">150.00 Rs</div>
		</div>
	
     <div class="product" data-name="p-2">
			<img src="imag/oil.jpg" height="150px" width="90%" alt="">
			<h3>Sunflower Oil</h3>
			<div class="price">350.00 Rs</div>
		</div>
     
     <div class="product" data-name="p-3">
			<img src="imag/soap.jpg" height="150px" width="90%" alt="">
			<h3>Soap</h3>
			<div class="price">30.00 Rs</div>
		</div>
	
		<div class="product" data-name="p-4">
			<img src="imag/honey.jpg" height="150px" width="90%" alt="">
			<h3>Honey</h3>
			<div class="price">160.00 Rs</div>
		</div>
	
     <div class="product" data-name="p-5">
			<img src="imag/salt.jpg" height="150px" width="90%" alt="">
			<h3>TATA SALT</h3>
			<div class="price">35.00 Rs</div>
		</div>
     
     <div class="product" data-name="p-6">
			<img src="imag/souce.jpg" height="150px" width="90%" alt="">
			<h3>Kishan Ketchup</h3>
			<div class="price">100.00 Rs</div>
		</div>

			<div class="product" data-name="p-7">
			<img src="imag/milk.png" height="150px" width="90%" alt="">
			<h3>Milk</h3>
			<div class="price">31.5 Rs</div>
		</div>
	
     <div class="product" data-name="p-8">
			<img src="imag/bread.jpg" height="150px" width="90%" alt="">
			<h3>Bread</h3>
			<div class="price">60.00 Rs</div>
		</div>
     
     <div class="product" data-name="p-9">
			<img src="imag/rice.jpg" height="150px" width="90%" alt="">
			<h3>Rice</h3>
			<div class="price">300.00 Rs</div>
		</div>

	<div class="product" data-name="p-10">
			<img src="imag/suger.jpg" height="150px" width="90%" alt="">
			<h3>Suger</h3>
			<div class="price">250.00 Rs</div>
		</div>
	
     <div class="product" data-name="p-11">
			<img src="imag/surf.jpg" height="150px" width="90%" alt="">
			<h3>Surf Excel Powder</h3>
			<div class="price">75.00 Rs</div>
		</div>
     
     <div class="product" data-name="p-12">
			<img src="imag/bis.avif" height="150px" width="90%" alt="">
			<h3>Soap</h3>
			<div class="price">380.00 Rs</div>
		</div>
       </div>

<div class="products-preview">

   <div class="preview" data-target="p-1">
      <i class="fas fa-times"></i>
      <img src="imag/cofee.jpg" alt="">
      <h3>Cofee</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p>Coffee Makes Everything Possible,For People Who Love Coffe</p>
      <div class="price">150.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-2">
      <i class="fas fa-times"></i>
      <img src="imag/oil.jpg" alt="">
      <h3>sun flower oil</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p>People use sunflower oil for high cholesterol and preventing heart disease.</p>
      <div class="price">350.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-3">
      <i class="fas fa-times"></i>
      <img src="imag/soap.jpg" alt="">
      <h3>soap</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p>Pears Pure & Gentle: Pears is the gentle way to keep your skin looking innocent and beautiful.</p>
      <div class="price">30.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>



<div class="preview" data-target="p-4">
      <i class="fas fa-times"></i>
      <img src="imag/honey.jpg" alt="">
      <h3>HONEY</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p>DABUR HONEY – WORLD'S NO. 1 HONEY..</p>
      <div class="price">160.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-5">
      <i class="fas fa-times"></i>
      <img src="imag/salt.jpg" alt="">
      <h3>TATA SALT</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p>Supports a healthy nervous system,Improves sleep.</p>
      <div class="price">35.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-6">
      <i class="fas fa-times"></i>
      <img src="imag/souce.jpg" alt="">
      <h3>KISHAN KETCHUP</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p>The lip-smacking tastes and vibrant packaging ensures MAGGI Sauces stay true to its slogan</p>
      <div class="price">100.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>


<div class="preview" data-target="p-7">
      <i class="fas fa-times"></i>
      <img src="imag/milk.jpg" alt="">
      <h3>MILK</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p>Amul – 'The Taste of India'</p>
      <div class="price">31.5 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-8">
      <i class="fas fa-times"></i>
      <img src="imag/bread.jpg" alt="">
      <h3>BREAD</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">60.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-9">
      <i class="fas fa-times"></i>
      <img src="imag/rice.jpg" alt="">
      <h3>RICE</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">200.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

<div class="preview" data-target="p-10">
      <i class="fas fa-times"></i>
      <img src="imag/Suger.jpg" alt="">
      <h3>SUGER</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">350.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
         <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-11">
      <i class="fas fa-times"></i>
      <img src="imag/surf.jpg" alt="">
      <h3>SURF EXCEL POWDER</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">75.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>

   <div class="preview" data-target="p-12">
      <i class="fas fa-times"></i>
      <img src="imag/soap.jpg" alt="">
      <h3>BISCUIT</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>( 250 )</span>
      </div>
      <p></p>
      <div class="price">100.00 Rs</div>
      <div class="buttons">
         <a href="login_form.php" class="buy">buy now</a>
          <a href="Easy.php" class="cart">Easy For All</a>
      </div>
   </div>


</div>
</body>
</html>