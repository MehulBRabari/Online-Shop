<?php 

require_once('connection.php');

if(isset($_POST['submit']))
{
$user = $_POST['user'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$comments = $_POST['comments'];

$query = "INSERT INTO userfeedback (user,email,mobile,comments) VALUES('$user','$email','$mobile','$comments')";
$main_query = mysqli_query($conn,$query);

if($main_query)
{
   echo('Your Feedback send');
}
else
{
   echo('Error');
}
}
?>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/team.css">
  <link rel="stylesheet" type="text/css" href="css/contact.css">
  
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

 
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,300&display=swap" rel="stylesheet">

</head>
<body style="background-color:#D3DCE9">
 <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Our shop</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link active" aria-current="right" href="index.php">Home</a>
        </li>
        
		<li class="nav-item">
          <a class="nav-link active" href="shop.php">Shop</a>
        </li>
		
		<li class="nav-item">
          <a class="nav-link active" href="About.php">Team</a>
        </li>

        <li class="nav-item">
          <a class="nav-link active" href="contact.php">Contact</a>
        </li>
		
		 <li class="nav-item">
          <a class="nav-link active" href="register_form.php">Registration</a>
        </li>
		</a>
        </ul>
      </div>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"><t>_</t>
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
 
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="imag/shope.webp" alt="Los Angeles" width="1100" height="500">
      <div class="carousel-caption">
        <h3 class="h">Welcome to Our shop </h3>
        <p class="p">we anjoy shoping and purchase!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="imag/sale.avif" alt="Chicago" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Our Shop</h3>
        <p>Best offers to this week up to 80% off!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="imag/thank.jpg" alt="New York" width="1100" height="500">
      <div class="carousel-caption">
        <h3>india</h3>
        <p>Thank you so much for your support!</p>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>


<section class="my-5">
<div class="py-5">
    <h2 class="text-center">Our Services</h2>
  </div>
  <div class="containar-fluid">
    <div class="row">
<div class="col-lg-4 col-md-4 col-12">
<div class="card">
  <img class="card-img-top" src="imag/grocery.webp" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">All Grocery Product</h4>
    <p class="card-text">See ALl Product and Purchase.</p>
    <a href="grocery.php" class="btn btn-primary">See More Products</a>
  </div>
</div>
</div>

<div class="col-lg-4 col-md-4 col-12">
<div class="card">
  <img class="card-img-top" src="imag/electronic (2).jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">All Electronic Products</h4>
    <p class="card-text">See ALl Product and Purchase.</p>
    <a href="electronic.php" class="btn btn-primary">See More products</a>
  </div>
</div>
</div>


<div class="col-lg-4 col-md-4 col-12">
<div class="card">
  <img class="card-img-top" src="imag/furniture (4).jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">All Furniture and home Products</h4>
    <p class="card-text">See ALl Product and Purchase.</p>
    <a href="furniture.php" class="btn btn-primary">See More Products</a>
  </div>
</div>
</div>
</div>
</div>
</section>



<section class="my-5">
<div class="py-5">
  <h2 class="text-center">Letest Products Coming soon....</h2>
</div>

<div class="countainer-fluid">
  <div class="row">
<div class="col-lg-4 col-md-4 col-12">
<button><img src="imag/bike.avif" class="img-fluid pb-4"><button>
</div>
<div class="col-lg-4 col-md-4 col-12">
<button><img src="imag/i-13.jpg" class="img-fluid pb-4"></button>
</div>
<div class="col-lg-4 col-md-4 col-12">
<button><img src="imag/smart watch.jpg" class="img-fluid pb-4"></button>
</div>
<div class="col-lg-4 col-md-4 col-12">
  <button><img src="imag/fruit.jpg" class="img-fluid pb-4"></button>
</div>
<div class="col-lg-4 col-md-4 col-12">
 <button><img src="imag/ima.webp" class="img-fluid pb-4"></button>
</div>
<div class="col-lg-4 col-md-4 col-12">
  <button><img src="imag/oreo.webp" class="img-fluid pb-4"></button>
</div>
<div class="col-lg-4 col-md-4 col-12">
 <button><img src="imag/1st.webp" class="img-fluid pb-4"></button>
</div>
<div class="col-lg-4 col-md-4 col-12">
 <button><img src="imag/frame.jpg" class="img-fluid pb-4"></button>
</div>
<div class="col-lg-4 col-md-4 col-12">
  <button><img src="imag/stairs.jpg" class="img-fluid pb-4"></button>
</div>
</div>
 </section> 

<section class="my-5">
  <div class="py-5">
    <h2 class="text-center">Share your feedback..</h2>
  </div>
  <div class="w-50 m-auto">
  <form method="POST">
    <div class="form-group">
      <label>Username</label>  
      <input type="text" name="user" onautocomplete="off" class="form-control">
    </div>
  <div class="form-group">
      <label>Email</label>
      <input type="email" name="email" onautocomplete="off" class="form-control">
    </div>
<div class="form-group">
      <label>Mobile No</label>
      <input type="tel" name="mobile" onautocomplete="off" class="form-control">
    </div>
  <div class="form-group">
      <label>your feedback</label>
      <textarea class="form-control" name="comments">
      </textarea>
      <br></br>
      <input type="submit" name="submit" class="btn btn-success">
    </div>
  </form>
    </div>
  </section>
  <footer>
    <p class="p-3 bg-dark text-white text-center">@mehulcreationproduction</p>
  </footer>
</body>
</html>