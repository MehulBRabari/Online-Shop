
<?php
include 'db_conn.php';
$id=$_GET['id'];
$query="SELECT * FROM crud where id='$id'";
$data=mysqli_query($con,$query);
$row= mysqli_fetch_array($data);

?>

<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
	<title>Crud Application</title>
	</head>
<body style="color:white; background-color:#1d2630";>
<div class="container mt-5">
    <div class="text-center">
    	<h1 class="display-5 mb-5"><strong>Product Management</strong></h1>
	</div>
	<div class="main row justify-content-center">
    
    <form action="" id="product-form" method="POST" class="row justify-content-center mb-4" autocomplete="off">
    
    <div class="col-10 col-md-8 mb-3">
    <label>Product Name</label>
    <input class="form-control" value="<?php echo $row['p_name'] ?>"  name="p_name" type="text" placeholder="Enter the Products Name">
    </div>
    <div class="col-10 col-md-8 mb-3">
    <label>Product Price</label>
    <input class="form-control" value="<?php echo $row['p_price'] ?>" name="p_price" type="text" placeholder="Enter the Products Price">
    </div>
    <div class="col-10 col-md-8 mb-3">
    <label>Product Tag Line</label>
    <input class="form-control" value="<?php echo $row['p_tag'] ?>" name="p_tag" type="text" placeholder="Enter the Product Tag Line">
    </div>	
    <div class="col-10 col-md-8">
    <input class="btn btn-success add-btn" name="update" type="submit" value="update">
    <button><a href="crud.php" class="btn btn-success add-btn">BACK</a></button>
    </div>		
  </form>
 </div>

<?php
   if(isset($_POST['update'])) {
        $p_name = $_POST['p_name'];
        $p_price = $_POST['p_price'];
        $p_tag = $_POST['p_tag'];


      $update = "UPDATE crud SET p_name='$p_name',p_price ='$p_price',p_tag = '$p_tag'
      WHERE id = '$id'";
     $data = mysqli_query($con,$update);
     if($data) {
     ?>
     <script type="text/javascript">
     	alert("data updated successfuly");
     </script>
     <?php
     }
     else {
     	 ?>
     <script type="text/javascript">
     	alert("Plese try again");
     </script>
     <?php
    } 
   }
   ?>

</div>
</body>
 </html>