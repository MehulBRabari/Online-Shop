<html>
<head>
</head>
<body>
<div>
<img src="imag/dev.jpg" height="610px" width="100%" alt="">
<a href="shop.php">BACK</a>
</div>
</body>
</html>