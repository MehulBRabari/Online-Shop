<html>
<head>

<meta charset="UTF-8">
    <title> Responsive Contact Us Form  | CodingLab </title>
    <link rel="stylesheet" href="css/contact.css">
	 
	 
    <!-- Fontawesome CDN Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">






<style>

		
</style>
<body style="background-color:#D3DCE9">
<center>
<form>
<fieldset>
<legend><b>Customer Order Form</b></legend>
<h2>Customer Order Summery</h2>
<p><b>Enter  Your name:<input type="text" name="name"/></b></p>
<h3><b>Category</b></h3>
<p><b><input type="radio" name="Male" value="Male">Male</b>
<p><b><input type="radio" name="Female" value="Female">Female</b></p>

<p><b>Enter your mobile number:<select>
<option>+91</option>
<option>+78</option>
<option>+90</option>
<br><br>
<input type="tel" placeholder="number"/></p>
</select>
<br>
<p><b>Date of birth:<input type="date" placeholder="dd-mm-yyyy">dd-mm-yyyy</b></p><br>
<p><b>Email id:<input type="Email" placeholder="@domail.com">@domain.com</b></p><br>
<p><b>Enter Your Buy Product Name:<input type="text" name="username"/></b></p><br>
<p><b>Enter Your Buy Product Password<input type="text" name="password"></b></p><br>
<p><center>Enter Add Your Address</center><textarea rows="5" cols="50" placeholder="Address">
</textarea></p>
<br>
<button class="button"><input type="Submit" name="Submit" value="Submit"/></button>
<button class="button"><input type="reset" name="Reset" value="Reset" /></button>
</center>
</form>
</fieldset>
</body>
</html>
</html>