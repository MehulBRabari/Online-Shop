<html>
<head>
<meta charset="utf-8">
<title>Payment Process</title>
<link rel="stylesheet" type="text/css" href="css/paa.css"/>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<script>
</script>
</head>
<body style="color:white; background-color:#1d2630";/>
<div class="container mt-5;">
<form>
<header>
<button><a href="index.php">BACK</a></button>
<?php  
// define variables to empty values  
$name = $email = $address = $city = $state = $zip = $cardnum = $expmon = $year = $code = "";  
  
//Input fields validation  
//if ($_SERVER["REQUEST_METHOD"] == "POST") {  
if (isset($_POST['submit'])) {
	 $name = input_data($_POST["name"]); 	
   
   $email = input_data($_POST["email"]); 
  
    $address = input_data($_POST["address"]);  
  
   $city = input_data($_POST["city"]);  
  
    $state = input_data($_POST["state"]);  
  
    $zip = input_data($_POST["zip"]);  
  
    $cardnum = input_data($_POST["cardnum"]);  
  
    $expmon = input_data($_POST["expmon"]);  
  
   $year = input_data($_POST["year"]);  
  
    $code = input_data($_POST["code"]);  
  
}

function input_data($data) {  
  $data = trim($data);  
  $data = stripslashes($data);  
  $data = htmlspecialchars($data);  
  return $data;  
}  
?>
<?php  
    if(isset($_POST['submit'])) {  
        echo "<h3 color = #FF0001> <b>Your payment sucessfully.</b> </h3>";  
        echo "<h2>Your Payment Recipt:</h2>"; 
        echo "Name: " .$name;  
        echo "<br>";  
        echo "Email: " .$email;  
        echo "<br>";  
		echo "Address: " .$address;  
        echo "<br>"; 
        echo "City: " .$city;  
        echo "<br>";  
        echo "State: " .$state;  
        echo "<br>";  
        echo "zip: " .$zip;  
		echo "<br>";
		echo "cardnum:" .$cardnum;
		echo "<br>";
		echo "expmon" .$expmon;
		echo "<br>";
		echo "year:".$year;
		echo "<br>";
		echo "CVV:" .$code;
    }  
?>  
</div>
</header>
</form>
</body>
</html>