<?php

require_once('connection.php');

?>

<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
	<title>Crud Application</title>
</head>
<body style="color:white; background-color:#1d2630";>
	<div class="container mt-5">
    <div class="text-center">
    	<h1 class="display-5 mb-5"><strong>Product Management</strong></h1>
	</div>
	<div class="main row justify-content-center">
    
    <form action="" id="product-form" method="POST" class="row justify-content-center mb-4" autocomplete="off">
    
    <div class="col-10 col-md-8 mb-3">
    <label>Product Name</label>
    <input class="form-control"  name="p_name" type="text" placeholder="Enter the Products Name">
    </div>
    <div class="col-10 col-md-8 mb-3">
    <label>Product Price</label>
    <input class="form-control" name="p_price" type="text" placeholder="Enter the Products Price">
    </div>
    <div class="col-10 col-md-8 mb-3">
    <label>Product Tag Line</label>
    <input class="form-control" name="p_tag" type="text" placeholder="Enter the Product Tag Line">
    </div>	
    <div class="col-10 col-md-8">
    <input class="btn btn-success add-btn" name="submit" type="submit" value="submit">
	<a href="index.php" class="btn btn-success add-btn">BACK</a>
    </div>		
  </form>
  <div>
  	<?php
   if(isset($_POST['submit'])) {
        $p_name = $_POST['p_name'];
        $p_price = $_POST['p_price'];
        $p_tag = $_POST['p_tag'];
   
      $query ="INSERT INTO crud(p_name, p_price,p_tag) VALUES ('$p_name','$p_price','$p_tag')";
     $data = mysqli_query($conn,$query);
     if($data) {
     ?>
     <script type="text/javascript">
     	alert("data save successfuly");
     </script>
    <?php
	 }
     else {
     ?>
     <script type="text/javascript">
     	alert("Plese try again");
     </script>
     <?php
	 }
   }
   
   ?>


<?php
$id=$_GET['id'];
$query="DELETE FROM crud WHERE id='$id'";
$data=mysqli_query($conn,$query);
if($data) {
?>
<!--<script type="text/javascript">
	alert("Data deleted Successfully");
</script>-->
<?php 
}
else {
	?>
	<script type="text/javascript">
		alert("please try again");
	</script>
<?php
}
?>

<div class="col-12 col-md-10 mt-5">
<table class="table table-stripad table-dark">
	<thead>
		<tr>
			<th>Product Name</th>
			<th>Product Price</th>
			<th>Product Tag Line</th>
			<th>Action</th>
		</tr>
	</thead>
		<?php
     $query = "SELECT * FROM crud";
     $data = mysqli_query($conn,$query);
     $result = mysqli_num_rows($data);
     if($result) {
     	   while ($row=mysqli_fetch_array($data)){
     	   	?>
     	   	<tbody>
     	   	<tr>
     	   		<td><?php echo $row['p_name'];?></td> 
     	   		<td><?php echo $row['p_price'];?></td>
     	   		<td><?php echo $row['p_tag'];?></td>
     	   		<td>
			     <a href="updat.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm edit">Edit</a>
		         <a onclick="return confirm('Are you sure,you want to delet?')" href="crud.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm delete">Delete</a>
     	   	   </td>
			</tr>
     	   </tbody>
     	   	<?php
     	   }
     }
     else {

     }
	?>	


   

   <!-----<tbody >
	<tr>
		<td>Cofee</td>
		<td>50</td>
		<td>Cofee is Everithing</td>
		<td>
			<a href="#" class="btn btn-warning btn-sm edit">Edit</a>
			<a href="#" class="btn btn-danger btn-sm delete">Delete</a>
		</td>
	</tr>	
	</tbody>--->
</table>
  </div>
</div>
</div>
</body>
</html>