<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<title>Payment Process</title>
<link rel="stylesheet" type="text/css" href="css/payment.css"/>
</head>
<body  style="background-color:#D3DCE9;"/>
<?php  
// define variables to empty values  
$name = $email = $address = $city = $state = $zip = $cardnum = $expmon = $year = $code = "";  
  
//Input fields validation  
//if ($_SERVER["REQUEST_METHOD"] == "POST") {  
if (isset($_POST['submit'])) {
	 $name = input_data($_POST["name"]); 	
   
   $email = input_data($_POST["email"]); 
  
    $address = input_data($_POST["address"]);  
  
   $city = input_data($_POST["city"]);  
  
    $state = input_data($_POST["state"]);  
  
    $zip = input_data($_POST["zip"]);  
  
    $cardnum = input_data($_POST["cardnum"]);  
  
    $expmon = input_data($_POST["expmon"]);  
  
   $year = input_data($_POST["year"]);  
  
    $code = input_data($_POST["code"]);  
  
}

function input_data($data) {  
  $data = trim($data);  
  $data = stripslashes($data);  
  $data = htmlspecialchars($data);  
  return $data;  
}  
?>  
<form method="post" action="pa.php" > 
<header>
<div class="container">
<div class="left">
<h3>BILLING ADDRESS</h3>
FULL NAME:
<input type="text" name="name" placeholder="Enter name">
EMAIL:
<input type="text" name="email" placeholder="Enter email">
ADDRESS:
<input type="text" name="address" placeholder="Enter address">
CITY:
<input type="text" name="city" placeholder="Enter city">
<div id="ZIP">
<label>
state:
<select name="state">
<option name="state">Chose our state</option>
<option name="state">Gujarat</option>
<option name="state">Rajasthan</option>
<option name="state">Hariyana</option>
<option name="state">Punjab</option>
<option name="state">Maharstra</option>
<option name="state">Goa</option>
<option name="state">Uttar Pradesh</option>
<option name="state">Madya Pradesh</option>
<option name="state">Delhi</option>
<option name="state">Jamu-Kashmir</option>
</select>
</label>
<label>
Zip code:
<input type="number" name="zip" placeholder="Zip code">
</label>
</div>
</div>
<div class="right">
<h3>Payment</h3>
<div class="ha">
QR Code scan
</div>
<div class="ph">
<img src="imag/qr.png" width="100">
</div>
Accsepted card:<br><br>
<img src="imag/coral-card.webp" width="50">
<img src="imag/ca.webp" width="50">
<img src="imag/cradi.jpg" width="50">
<img src="imag/debi.jpg" width="50">
<br><br>
cradit card number:
<input type="text" name="cardnum" placeholder="Enter card number">
Pay Rs.:
<input type="text" name="expmon" placeholder="Enter Amount">
<div id="ZIP">
<label>
Exp Year:
<select name="year">
<option name="year">Chose Exp Year</option>
<option name="year">2023</option>
<option name="year">2024</option>
<option name="year">2025</option>
<option name="year">2026</option>
<option name="year">2027</option>
</select>
</label>
<label>
CVV:
<input type="number" name="code" placeholder="Zip code">
</label>
</div>
<input type="submit" name="submit" onclick="return confirm('Your pyment is succsefullt plese collect your payment recipt')" value="Process  to chackout">
</div>
</div>
</header>
<?php  
    if(isset($_POST['submit'])) {  
        echo "<h3 color = #FF0001> <b>Your payment sucessfully.</b> </h3>";  
        echo "<h2>Your Payment Recipt:</h2>";  
        echo "Name: " .$name;  
        echo "<br>";  
        echo "Email: " .$email;  
        echo "<br>";  
		echo "Email: " .$address;  
        echo "<br>"; 
        echo "City: " .$city;  
        echo "<br>";  
        echo "State: " .$state;  
        echo "<br>";  
        echo "zip: " .$zip;  
		echo "<br>";
		echo "cardnum:" .$cardnum;
		echo "<br>";
		echo "expmon" .$expmon;
		echo "<br>";
		echo "year:".$year;
		echo "<br>";
		echo "CVV:" .$code;
    }  
?>  
</form>
</body>
</html>