<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "shoping";

$con = mysqli_connect($host,$user,$pass,$db);

if($con) {
	echo "Ok";
}
else {
	echo "Database Not connected";
}
?>